package pl.javastart.Mp3Player.player;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;

public class Listener implements ChangeListener {
    @Override
    public void changed(ObservableValue observableValue, Object o, Object t1) {

    }
}
