package pl.javastart.Mp3Player.mp3;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.stage.Stage;
import org.farng.mp3.MP3File;
import org.farng.mp3.TagException;
import pl.javastart.Mp3Player.Controller.ContentPaneController;
import pl.javastart.Mp3Player.Controller.LoadingFileController;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;

public class Mp3Parser implements Serializable {
    public static final Long serialVersionUID = 492481425839593L;
    @FXML
    private static LoadingFileController loadingFileController;

    public static LoadingFileController getLoadingFileController() {
        return loadingFileController;
    }


    public Mp3Song createMp3Song(File file) throws IOException, TagException {
        MP3File mp3File = new MP3File(file);
        String absolutePath = file.getAbsolutePath();
        String title = null;
        String author = null;
        String album = null;
        CheckBox checkBox = null;
        if (mp3File.getID3v2Tag() != null && file != null && mp3File != null) {
            title = mp3File.getID3v2Tag().getSongTitle();
            author = mp3File.getID3v2Tag().getLeadArtist();
            album = mp3File.getID3v2Tag().getAlbumTitle();
            checkBox = new CheckBox();
            return new Mp3Song(title, author, album, absolutePath, checkBox);
        } else {
            return null;
        }

    }


    public List<Mp3Song> createMp3List(File dir) throws IOException, TagException, FileNotFoundException {

        List<File> fileList = new ArrayList<>();
        List<Mp3Song> songList = new ArrayList<>();
        Long timeByforeSearchingComplexedDirectoriee = System.nanoTime();

        createFileListFromComplexedDirectories(dir, fileList);

        Long timeAfterSearchingComplexedDirectoriee = System.nanoTime();


        Long durationOfSearchingComplexedDirectoriee = timeAfterSearchingComplexedDirectoriee - timeByforeSearchingComplexedDirectoriee;
        System.out.println("durationOfSearchingComplexedDirectoriee=  " + durationOfSearchingComplexedDirectoriee);

        List<Mp3Song> songListT = new ArrayList<>();


        Long timeBYforeLoopAddingMp3SongToSongList = System.nanoTime();

        Task progressTask = new Task<Void>() {
            @Override
            public Void call() throws Exception {
                int i;
                for (i = 0; i < fileList.size(); i++) {
                    try {

                        String fileExtension = fileList.get(i).getName().substring(fileList.get(i).getName().lastIndexOf(".") + 1);


                        if (fileExtension.equals("mp3") && createMp3Song(fileList.get(i)) != null) {

                            songListT.add(createMp3Song(fileList.get(i)));


                            updateProgress(i, fileList.size() - 1);
                            updateMessage(fileList.get(i).getName());

                        }

                    } catch (FileNotFoundException fnf) {

                        continue;// przejdź do następnej iteracji
                    }
                }
                return null;
            }
        };

        createNewWidnowWithProgressBarofAddingMp3Song(progressTask);
        new Thread(progressTask).start();

        Long timeAfterCreatingSongList = System.nanoTime();
        Long durationOfCreatingSongList = timeAfterCreatingSongList - timeBYforeLoopAddingMp3SongToSongList;
        System.out.println("durationOfCreatingSongList" + durationOfCreatingSongList);

        boolean checkWhichOperationTakesMoreTime = durationOfCreatingSongList > durationOfSearchingComplexedDirectoriee;
        System.out.println("tworzenie songlist jest dłuższe od przeszukiwania folderów=  " + checkWhichOperationTakesMoreTime);
        System.out.println("durationOfCreatingSonglist/DurationofSearchingDirectories=  " + durationOfCreatingSongList / durationOfSearchingComplexedDirectoriee);


        songList = songListT;

        return songList;
    }

    private void createFileListFromComplexedDirectories(File dir, List<File> fileList) throws FileNotFoundException {

        if (dir.listFiles() != null) {
            File[] temporaryFilesTable = dir.listFiles();

            for (File file : temporaryFilesTable) {


                try {

                    if (file.isDirectory()) {

                        createFileListFromComplexedDirectories(file, fileList);// wywłujemy jeszcze raz rekurencyjnie dla kazdego podfolderu

                    } else if (!file.isDirectory()) {
                        fileList.add(file);
                    }


                } catch (FileNotFoundException e) {


                    continue;

                }
            }


        }
    }


    private void createNewWidnowWithProgressBarofAddingMp3Song(Task task
    ) {
        FXMLLoader loader = new FXMLLoader();
        File playListNameFxml = new File("C:\\Users\\Marcin\\IdeaProjects\\mp3player\\src\\main\\java\\pl\\javastart\\Mp3Player\\Controller\\LoadingFileController.java");
        try {
            System.out.println(playListNameFxml.toURI().toURL());

        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        loader.setLocation(getClass().getResource("/fxml/loadingFilePane.fxml"));


        Parent parent = null;
        try {
            parent = loader.load();
            loadingFileController = loader.getController(); // zwraca obiekt kontrolera

            System.out.println(loadingFileController);

        } catch (IOException e) {
            e.printStackTrace();
        }
        Scene scene = new Scene(parent);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();
        stage.setTitle("Wczytywanie plików");

        Label songPath = loadingFileController.getFilePathLabel();
        ProgressBar progressBar = loadingFileController.getProgressBar();
        Label filePathLabel = loadingFileController.getFilePathLabel();

        progressBar.progressProperty().bind(task.progressProperty());
        filePathLabel.textProperty().bind(task.messageProperty());
        task.setOnSucceeded(workerStateEvent -> {
            stage.close();
        });


    }
}
